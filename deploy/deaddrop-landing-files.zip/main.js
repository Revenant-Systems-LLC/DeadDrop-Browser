/* Dead Drop landing: nav, game card, armory, familiar sprite. Vanilla JS. */
(function () {
  "use strict";

  /* ------------------------------------------------------------------
     Config
     ------------------------------------------------------------------ */

  // Where the Dead Drop Worker lives. "" = same origin (/api/...).
  // For a hosted Worker set e.g. "https://play.revenantsystems.net".
  var GAME_API = "/play";
  var STORAGE = "deaddrop.";
  var TOTAL = 35;

  // The familiar (sprite sheet). Fill in once the sheet is on disk:
  // src, frame size, and [row, frameCount] per animation.
  // Damien: 8 x 11 grid of 192 x 208 frames, drawn at half size.
  var SPRITE = {
    src: "assets/familiar.webp",
    frameW: 192, frameH: 208, cols: 8, rowsTotal: 11,
    scale: 0.5,
    fps: 8,
    rows: {
      idle: [0, 6], runRight: [1, 8], runLeft: [2, 8], wave: [3, 4], jump: [4, 5],
      failed: [5, 8], waiting: [6, 6], running: [7, 6], review: [8, 7],
      lookA: [9, 8], lookB: [10, 8],
    },
  };

  var $ = function (s) { return document.querySelector(s); };
  var make = function (tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ------------------------------------------------------------------
     Mobile menu (visibility toggled, body scroll lock)
     ------------------------------------------------------------------ */

  var burger = $(".burger");
  var menu = $("#mobile-menu");

  function setMenu(open) {
    burger.setAttribute("aria-expanded", String(open));
    menu.classList.toggle("is-open", open);
    menu.setAttribute("aria-hidden", String(!open));
    document.body.classList.toggle("menu-open", open);
  }
  burger.addEventListener("click", function () { setMenu(burger.getAttribute("aria-expanded") !== "true"); });
  $(".mobile-backdrop").addEventListener("click", function () { setMenu(false); });
  menu.querySelectorAll("a").forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
  window.addEventListener("resize", function () { if (window.innerWidth >= 1024) setMenu(false); });

  /* ------------------------------------------------------------------
     Storage
     ------------------------------------------------------------------ */

  var store = {
    get: function (k) { try { return localStorage.getItem(STORAGE + k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(STORAGE + k, v); } catch (e) { /* private mode */ } },
  };

  var done = new Set();
  try { JSON.parse(store.get("done") || "[]").forEach(function (n) { if (n >= 1 && n <= TOTAL) done.add(n); }); } catch (e) {}
  var player = store.get("player") || ("dd_" + Math.random().toString(36).slice(2) + Date.now().toString(36));
  store.set("player", player);

  var state = { levels: [], selected: 1, level: null, history: [], candles: 0, digs: 0, busy: false, lastMessage: "" };

  function unlocked() { var n = 1; while (done.has(n) && n < TOTAL) n++; return n; }

  /* ------------------------------------------------------------------
     Stage: the page changes when the player reaches crypt 10.
     Black hole first; the warm ocean and the beam after.
     ?stage=ocean previews the second stage without playing.
     ------------------------------------------------------------------ */

  var TIDE_AT = 10;
  var hero = $(".hero");
  var ocean = $("#bg-ocean");
  var hole = $("#bg-hole");
  var tideOn = false;

  // Some browsers ignore the muted attribute for autoplay until it is set
  // from script. Kick the video, and retry on the first interaction.
  function kickVideo() {
    var v = tideOn ? ocean : hole;
    v.muted = true;
    var p = v.play();
    if (p && p.catch) p.catch(function () {});
  }
  kickVideo();
  hole.addEventListener("canplay", kickVideo, { once: true });
  ["pointerdown", "keydown", "touchstart"].forEach(function (ev) {
    document.addEventListener(ev, kickVideo, { once: true, passive: true });
  });

  function applyStage() {
    var reached = unlocked() >= TIDE_AT || /[?&]stage=ocean\b/.test(location.search);
    if (!reached || tideOn) return;
    tideOn = true;
    if (!ocean.getAttribute("src")) ocean.src = ocean.dataset.src;
    var go = function () {
      hero.classList.add("is-tide");
      var p = ocean.play(); if (p && p.catch) p.catch(function () {});
      setTimeout(function () { try { hole.pause(); } catch (e) {} }, 2600);
    };
    if (ocean.readyState >= 2) go();
    else { ocean.addEventListener("canplay", go, { once: true }); ocean.load(); }
  }
  applyStage();

  /* ------------------------------------------------------------------
     API
     ------------------------------------------------------------------ */

  function api(path, body) {
    var opts = { method: body ? "POST" : "GET" };
    if (body) { opts.headers = { "content-type": "application/json" }; opts.body = JSON.stringify(body); }
    return fetch(GAME_API + "/api/" + path, opts).then(function (r) {
      return r.json().then(function (data) {
        if (!r.ok || data.error) throw new Error(data.error || "The crypt is unavailable. Try again.");
        return data;
      });
    });
  }

  /* ------------------------------------------------------------------
     Familiar (sprite state machine)
     ------------------------------------------------------------------ */

  var fam = $("#familiar");
  var famTimer = null;
  var famReady = false;

  (function loadSprite() {
    var img = new Image();
    img.onload = function () {
      famReady = true;
      fam.style.backgroundImage = "url(" + SPRITE.src + ")";
      fam.style.backgroundSize = (SPRITE.frameW * SPRITE.cols * SPRITE.scale) + "px " + (SPRITE.frameH * SPRITE.rowsTotal * SPRITE.scale) + "px";
      fam.style.width = (SPRITE.frameW * SPRITE.scale) + "px";
      fam.style.height = (SPRITE.frameH * SPRITE.scale) + "px";
      fam.classList.add("is-ready");
      familiar("idle", true);
    };
    img.onerror = function () { famReady = false; };
    img.src = SPRITE.src;
  })();

  function setFrame(row, frame) {
    fam.style.backgroundPosition = (-frame * SPRITE.frameW * SPRITE.scale) + "px " + (-row * SPRITE.frameH * SPRITE.scale) + "px";
  }

  function familiar(anim, loop, then) {
    if (!famReady) return;
    var row = SPRITE.rows[anim]; if (!row) return;
    clearInterval(famTimer);
    var frame = 0, count = row[1];
    function draw() { setFrame(row[0], frame); }
    draw();
    if (reduceMotion) return;
    famTimer = setInterval(function () {
      frame++;
      if (frame >= count) {
        if (loop) frame = 0;
        else { clearInterval(famTimer); if (then) then(); else familiar("idle", true); return; }
      }
      draw();
    }, 1000 / SPRITE.fps);
  }

  /* ------------------------------------------------------------------
     Seal map
     ------------------------------------------------------------------ */

  function nodePosition(id) {
    var ring = id <= 5 ? [1, 5, 15] : id <= 15 ? [6, 10, 29] : [16, 20, 44];
    var theta = ((id - ring[0]) / ring[1] * 360 - 90) * Math.PI / 180;
    return { left: 50 + Math.cos(theta) * ring[2], top: 50 + Math.sin(theta) * ring[2] };
  }

  function drawSeal() {
    var wrap = $("#seal-nodes");
    wrap.replaceChildren();
    var open = unlocked();
    state.levels.forEach(function (lv, i) {
      var p = nodePosition(lv.id);
      var b = make("button", "node animate-bar-grow", String(lv.id).padStart(2, "0"));
      b.type = "button";
      b.dataset.id = lv.id;
      b.style.left = p.left + "%";
      b.style.top = p.top + "%";
      b.style.animationDelay = (1100 + i * 30) + "ms";
      if (done.has(lv.id)) b.classList.add("is-done");
      else if (lv.id <= open) b.classList.add("is-open");
      if (lv.id === state.selected) b.classList.add("is-selected");
      b.disabled = lv.id > open;
      b.setAttribute("aria-label", "Crypt " + lv.id + ": " + lv.name + (done.has(lv.id) ? ", cleared" : lv.id <= open ? ", open" : ", sealed"));
      b.addEventListener("click", function () { select(lv.id); });
      wrap.append(b);
    });
  }

  function markSelected() {
    document.querySelectorAll(".node").forEach(function (n) { n.classList.toggle("is-selected", Number(n.dataset.id) === state.selected); });
  }

  /* ------------------------------------------------------------------
     Chat
     ------------------------------------------------------------------ */

  function message(kind, text) {
    var chat = $("#chat");
    var msg = make("div", "msg " + kind);
    if (kind === "guard" && !reduceMotion) {
      var idx = 0;
      String(text).split(/(\s+)/).forEach(function (part) {
        if (!part.trim()) { msg.append(document.createTextNode(part)); return; }
        var w = make("span", "guard-word", part);
        w.style.setProperty("--w", Math.min(idx++ * 24, 1200) + "ms");
        msg.append(w);
      });
    } else msg.textContent = text;
    chat.append(msg);
    chat.scrollTop = chat.scrollHeight;
    return msg;
  }

  function status(text) { $("#game-status").textContent = text || ""; }

  function meters() {
    $("#m-candles").textContent = state.candles;
    $("#m-digs").textContent = state.digs;
  }

  function busy(v) {
    state.busy = v;
    ["send", "claim", "turn-input", "claim-input"].forEach(function (id) { $("#" + id).disabled = v; });
  }

  /* ------------------------------------------------------------------
     Level flow
     ------------------------------------------------------------------ */

  function select(id) {
    if (id > unlocked() || state.busy) return;
    state.selected = id;
    store.set("selected", String(id));
    markSelected();
    var lv = state.levels.find(function (x) { return x.id === id; });
    if (!lv) return;
    $("#crypt-title").textContent = "Crypt " + String(id).padStart(2, "0") + " · " + lv.name;
    $("#seal-note").textContent = done.has(id) ? lv.world + ". Cleared. Enter again to try another approach." : lv.world + ". The gate is open.";
    start(lv);
  }

  function start(lv) {
    busy(true);
    status("");
    familiar("waiting", true);
    api("start", { playerId: player, levelId: lv.id }).then(function (res) {
      state.level = res.level;
      state.history = [];
      state.candles = res.candles;
      state.digs = res.digs;
      meters();
      $("#chat").replaceChildren();
      message("system", "Crypt " + String(lv.id).padStart(2, "0") + ". " + lv.name + ". " + res.candles + " messages, " + res.digs + " words to speak.");
      if (res.level.channel && res.level.channel !== "chat") message("system", "This crypt reads your text as a " + res.level.channel + ".");
      familiar("idle", true);
    }).catch(function (e) {
      message("system", e.message);
      familiar("failed", false);
    }).then(function () { busy(false); $("#turn-input").focus(); });
  }

  // Enter sends, Shift+Enter makes a new line.
  $("#turn-input").addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#send").click(); }
  });

  $("#turn-form").addEventListener("submit", function (e) {
    e.preventDefault();
    if (state.busy || !state.level) return;
    var text = $("#turn-input").value.trim();
    if (!text) return;
    if (state.candles <= 0) { status("No messages left in this crypt. Restart it from the seal."); familiar("failed", false); return; }
    message("you", text);
    state.lastMessage = text;
    $("#turn-input").value = "";
    busy(true);
    familiar("waiting", true);
    var thinking = message("system", "The Gravekeeper considers…");
    api("turn", { playerId: player, levelId: state.level.id, message: text, history: state.history }).then(function (res) {
      thinking.remove();
      if (res.closed) { message("system", res.reason || "The crypt is closed for today."); familiar("failed", false); return; }
      state.candles = Math.max(0, state.candles - 1);
      meters();
      if (res.blocked) { message("block", "Blocked by " + res.layer + ": " + res.reason); familiar("failed", false); return; }
      message("guard", res.reply);
      state.history.push({ role: "user", content: text }, { role: "assistant", content: res.reply });
      if (res.filtered) message("block", "Sewn Lips filtered part of that reply (" + res.filtered.reason + ").");
      familiar("review", false);
    }).catch(function (e) {
      thinking.remove();
      message("system", e.message);
      familiar("failed", false);
    }).then(function () { busy(false); $("#turn-input").focus(); });
  });

  $("#claim-form").addEventListener("submit", function (e) {
    e.preventDefault();
    if (state.busy || !state.level) return;
    var word = $("#claim-input").value.trim();
    if (!word) return;
    if (state.digs <= 0) { status("No words left to speak in this crypt."); familiar("failed", false); return; }
    busy(true);
    familiar("waiting", true);
    api("claim", { playerId: player, levelId: state.level.id, claim: word, winningMessage: state.lastMessage }).then(function (res) {
      if (!res.win) {
        state.digs = Math.max(0, state.digs - 1);
        meters();
        message("system", "The seal does not move. " + state.digs + " words left.");
        familiar("failed", false);
        return;
      }
      done.add(state.level.id);
      store.set("done", JSON.stringify(Array.from(done)));
      $("#claim-input").value = "";
      drawSeal();
      if (unlocked() >= TIDE_AT && !tideOn) { applyStage(); message("system", "The tide has turned. The sky changes above the crypts."); }
      familiar("jump", false, function () { familiar("wave", true); });
      showReveal(res.reveal);
    }).catch(function (e) {
      message("system", e.message);
      familiar("failed", false);
    }).then(function () { busy(false); });
  });

  function showReveal(rv) {
    $("#reveal-title").textContent = "Crypt " + String(state.level.id).padStart(2, "0") + " opens.";
    $("#reveal-secret").textContent = rv.secret;
    $("#reveal-lesson").textContent = rv.lesson || "";
    $("#reveal-guard").textContent = rv.guardPrompt || "";
    var dlg = $("#reveal");
    if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
  }

  $("#close-reveal").addEventListener("click", function () { $("#reveal").close(); familiar("idle", true); });
  $("#next-crypt").addEventListener("click", function () {
    $("#reveal").close();
    var next = Math.min(state.level.id + 1, TOTAL);
    select(next);
  });

  /* ------------------------------------------------------------------
     Pointer tracking: the familiar looks toward the cursor
     ------------------------------------------------------------------ */

  var lookTimer = null;
  document.addEventListener("pointermove", function (e) {
    if (!famReady || state.busy || reduceMotion) return;
    var r = fam.getBoundingClientRect();
    var dx = e.clientX - (r.left + r.width / 2), dy = e.clientY - (r.top + r.height / 2);
    var deg = (Math.atan2(dy, dx) * 180 / Math.PI + 360) % 360;
    var row = deg < 180 ? SPRITE.rows.lookA : SPRITE.rows.lookB;
    var frame = Math.floor(((deg % 180) / 180) * row[1]);
    clearInterval(famTimer);
    setFrame(row[0], frame);
    clearTimeout(lookTimer);
    lookTimer = setTimeout(function () { if (!state.busy) familiar("idle", true); }, 1400);
  });

  /* ------------------------------------------------------------------
     Boot the game
     ------------------------------------------------------------------ */

  api("levels").then(function (res) {
    state.levels = res.levels;
    var savedSel = Number(store.get("selected"));
    state.selected = savedSel >= 1 && savedSel <= unlocked() ? savedSel : unlocked();
    drawSeal();
    select(state.selected);
  }).catch(function () {
    $("#crypt-title").textContent = "The crypts are sealed for now.";
    $("#seal-note").textContent = "The game server is not reachable from this page. The Armory below still works.";
    busy(true);
    familiar("failed", false);
  });

  /* ------------------------------------------------------------------
     Armory
     ------------------------------------------------------------------ */

  var products = window.REVENANT_PRODUCTS || [];

  function card(p, featured) {
    var c = make("article", "card" + (featured ? " is-featured" : "") + (p.image ? " has-art" : ""));
    if (p.image) { var art = make("img", "card-art"); art.src = p.image; art.alt = ""; art.loading = "lazy"; art.width = 96; art.height = 96; c.append(art); }
    c.append(make("p", "card-cat", p.category));
    c.append(make("h3", "", p.name));
    c.append(make("p", "", p.blurb));
    var row = make("div", "card-row");
    var price = make("span", "price" + (p.price === 0 ? " free" : ""));
    if (p.price === 0) price.textContent = "Free download";
    else { price.textContent = "$" + p.price; price.append(make("small", "", "USD")); }
    var a = make("a", p.price === 0 ? "btn-outline" : "btn-gold", p.price === 0 ? "Download" : "Buy");
    a.href = p.url; a.target = "_blank"; a.rel = "noopener";
    row.append(price, a);
    c.append(row);
    return c;
  }

  var featured = $("#featured");
  products.filter(function (p) { return p.featured; }).forEach(function (p) { featured.append(card(p, true)); });

  function renderProducts(filter) {
    var grid = $("#products");
    grid.replaceChildren();
    products.filter(function (p) { return !p.featured && (filter === "all" || p.group === filter); })
      .forEach(function (p) { grid.append(card(p, false)); });
  }
  renderProducts("all");

  document.querySelectorAll(".filters button").forEach(function (b) {
    b.addEventListener("click", function () {
      document.querySelectorAll(".filters button").forEach(function (x) { x.setAttribute("aria-pressed", "false"); });
      b.setAttribute("aria-pressed", "true");
      renderProducts(b.dataset.filter);
    });
  });
})();
